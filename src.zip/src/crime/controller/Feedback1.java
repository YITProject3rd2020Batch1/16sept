package crime.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import crime.dao.*;
import crime.model.*;

/**
 * Servlet implementation class Feedback
 */
@WebServlet("/Feedback1")
public class Feedback1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	int n=1;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
   
   
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		response.setContentType("text/html");
		PrintWriter out= response.getWriter(); 
		int com_id=Integer.parseInt(request.getParameter("com_id"));
		String adm_rmk=request.getParameter("adm_rmk");
		String asgd_po=request.getParameter("asgd_po");
		Complaintmodel c3=new Complaintmodel();
		c3.setCom_id(com_id);
		c3.setAsgd_po(asgd_po);
		c3.setAdm_rmk(adm_rmk);
	    if(FeedbackDAO.feedback1(c3)==true)
	    {
	    	rd=request.getRequestDispatcher("adminhome.jsp");
	    	rd.forward(request, response);
	    }
	    else
	    {
	    	request.setAttribute("errormsg", "PLEASE enter correct complaint ID!!!");
	    	rd=request.getRequestDispatcher("feedback1.jsp");
	    	rd.forward(request, response);
	    }
		
		
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}


