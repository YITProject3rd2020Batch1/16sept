package crime.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import crime.dao.*;
import crime.model.*;
/**
 * Servlet implementation class Regcrime
 */
@WebServlet("/Regcrime")
public class Regcrime extends HttpServlet {
	private static final long serialVersionUID = 1L;
	int n=1;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Regcrime() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		RequestDispatcher rd;
		
		//int com_id=Integer.parseInt(request.getParameter("com_id"));
		String com_type=request.getParameter("com_type");
		String date=request.getParameter("date");
		String victim_det=request.getParameter("victim_det");
		String location=request.getParameter("location");
		String det_com=request.getParameter("det_com");
		String email=request.getParameter("email");
	
			Complaintmodel c1=new Complaintmodel();
			c1.setCom_id(n);
			n++;
			c1.setCom_type(com_type);
			c1.setDate(date);
			c1.setVictim_det(victim_det);
			c1.setLocation(location);
			c1.setDet_com(det_com);
			c1.setEmail(email);
			if(RegcrimeDAO.registercrime(c1)==true)
			{
			rd=request.getRequestDispatcher("userhome.jsp");
			rd.forward(request, response);
			}
		else
			{
				request.setAttribute("errormsg", "NOT ABLE TO REGISTER YOUR COMPLAINT");
				rd=request.getRequestDispatcher("reg_crime.jsp");
				rd.forward(request, response);
			}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
