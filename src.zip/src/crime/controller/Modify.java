package crime.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import crime.dao.*;
import crime.model.*;

@WebServlet("/Modify")
public class Modify extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd=null;
		int com_id;
		Complaintmodel temp;
		if(request.getParameter("oper")!=null)
		{
			if(request.getParameter("oper").equals("modify") )
			{
				com_id=Integer.parseInt(request.getParameter("com_id"));		
				
			   
			    temp=ViewDAO.getComplaintsByCom_id(com_id);
			    if(temp!=null)
			    {
			    	request.setAttribute("complaint", temp);
			    	rd=request.getRequestDispatcher("edit_com.jsp");
			    	rd.forward(request, response);
			    }
			    
			}
			
		}
		if(request.getParameter("confirmupdate")!=null)
		{
			com_id=Integer.parseInt(request.getParameter("com_id"));	
			String com_type=request.getParameter("com_type");
			String det_com=request.getParameter("det_com");
			String location=request.getParameter("location");
			String victim_det=request.getParameter("victim_det");
			String date=request.getParameter("date");

			
			
		
			temp = new Complaintmodel();
			temp.setCom_id(com_id);
			temp.setCom_type(com_type);
			temp.setDet_com(det_com);
			temp.setLocation(location);
			temp.setVictim_det(victim_det);
			temp.setDate(date);
			if(ViewDAO.updateComplaintByCom_id(temp))
			{
			 	request.setAttribute("successmsg", "Updated succssfully");
			rd=request.getRequestDispatcher("view.jsp");
    	    rd.forward(request, response);
			}
			else
			{
				request.setAttribute("errormsg", "Not updated");			 
			rd=request.getRequestDispatcher("edit_com.jsp");
    	    rd.forward(request, response);
		}
		}
 	   
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
