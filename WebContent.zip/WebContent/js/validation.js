function checkEmpty(data)
{
	if(data==undefined || data == null || data.trim() == '')
			return false;			
	return true;
}
function checkPwdLength(data)
{
	if(data==undefined && data == null || data.trim() == '')
			return false;
	else if(data.length<6)
			return false;			
	return true;
}
function checkMobileNo(data)
{
	if(data==undefined && data == null || data.trim() == '')
	    return false;	
	else if(Number.isInteger(data))
		return false;	
	else if(data.length!=10)  	
	    return false;			
	return true;
}



//registration


function checkAll()
{
	var uname=document.getElementById("Name").value;	
	if(checkEmpty(uname)==false)
	{
		alert("Usename is not assigned or invalid data");
		return false;
	}
	var ema=document.getElementById("Email").value;
	if(checkEmpty(ema)==false)
	{
		alert("Please enter your email");
		return false;
	}
	var pwd1=document.getElementById("Pass").value;
	var pwd2=document.getElementById("Pass1").value;
	if(checkEmpty(pwd1)==false || checkEmpty(pwd2)==false || pwd1!=pwd2)
	{
		alert("Passsword not assigned or not matched");
		return false;
	}
	
	var add=document.getElementById("Add").value;
	if(checkEmpty(add)==false)
	{
		alert("Please enter your address");
		return false;
	}
	var no=document.getElementById("num").value;
	if(checkEmpty(no)==false)
	{
		alert("Please enter your contact number");
		return false;
	}
	var maleRB=document.getElementById("Male");
	var femaleRB=document.getElementById("Female");
	var otherRB=document.getElementById("Other");
	if(maleRB.checked==false && femaleRB.checked==false && otherRB.checked==false)
	{
		alert("Please select gender");
		return false;
	}
	var sans=document.getElementById("Secans").value;
	if(checkEmpty(sans)==false)
	{
		alert("Please enter your answer");
		return false;
	}
	return true;	
}



//login


function checkAll1()
{
	var ema=document.getElementById("Email").value;
	if(checkEmpty(ema)==false)
	{
		alert("Please enter your email");
		return false;
	}
	var pwd1=document.getElementById("Pass").value;
	if(checkEmpty(pwd1)==false)
	{
		alert("Enter your password");
		return false;
	}
	return true;	
}


//edit profile


function checkAll2()
{
	var uname=document.getElementById("Name").value;	
	if(checkEmpty(uname)==false)
	{
		alert("Usename is not assigned or invalid data");
		return false;
	}
	var ema=document.getElementById("Email").value;
	if(checkEmpty(ema)==false)
	{
		alert("Please enter your email");
		return false;
	}
	var add=document.getElementById("Add").value;
	if(checkEmpty(add)==false)
	{
		alert("Please enter your address");
		return false;
	}
	var no=document.getElementById("num").value;
	if(checkEmpty(no)==false)
	{
		alert("Please enter your contact number");
		return false;
	}var pwd1=document.getElementById("Pass").value;
	var pwd2=document.getElementById("Pass1").value;
	if(checkEmpty(pwd1)==false || checkEmpty(pwd2)==false || pwd1!=pwd2)
	{
		alert("Passsword not assigned or not matched");
		return false;
	}
	
	return true;	
}


//forgot password


function checkAll3()
{
	
	var ema=document.getElementById("Email").value;
	if(checkEmpty(ema)==false)
	{
		alert("Please enter your email");
		return false;
	}
	var sans=document.getElementById("Secans").value;
	if(checkEmpty(sans)==false)
	{
		alert("Please enter your answer");
		return false;
	}
	return true;	
}


//report

function checkAll4()
{
	
	var rid=document.getElementById("Repid").value;
	if(checkEmpty(rid)==false)
	{
		alert("Please enter ReportID");
		return false;
	}
	var date=document.getElementById("Repdate").value;
	if(checkEmpty(date)==false)
	{
		alert("Please enter date");
		return false;
	}
	var det=document.getElementById("Repdet").value;
	if(checkEmpty(det)==false)
	{
		alert("Please enter details");
		return false;
	}
	var cid=document.getElementById("Comid").value;
	if(checkEmpty(cid)==false)
	{
		alert("Please enter ComplaintID");
		return false;
	}
	return true;	
}


//password check

function myFunction() {
	  var x = document.getElementById("Pass");
	  if (x.type === "password") {
	    x.type = "text";
	  } else {
	    x.type = "password";
	  }
	}